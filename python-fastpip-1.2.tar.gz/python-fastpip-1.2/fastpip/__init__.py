# -*- coding: utf-8 -*-

from .fastpip import pip  # NOQA
