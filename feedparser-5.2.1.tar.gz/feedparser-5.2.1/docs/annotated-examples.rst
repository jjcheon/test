.. _annotated:

Annotated Examples
##################

.. toctree::
   :maxdepth: 2

   annotated-atom10
   annotated-atom03
   annotated-rss20
   annotated-rss20-dc
   annotated-rss10

