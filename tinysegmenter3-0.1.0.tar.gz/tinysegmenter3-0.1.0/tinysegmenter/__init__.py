from .tinysegmenter import tokenize, _ctype
